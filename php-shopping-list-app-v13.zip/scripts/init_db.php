<?php
// Initierar SQLite DB med nödvändiga tabeller
