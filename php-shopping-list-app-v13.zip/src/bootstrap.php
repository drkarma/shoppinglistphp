<?php
// Startar session, inkluderar filer
