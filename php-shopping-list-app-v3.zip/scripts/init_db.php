<?php
declare(strict_types=1);

$dbPath = __DIR__ . '/../data/shoppinglist.sqlite';
if (file_exists($dbPath)) unlink($dbPath);

$db = new PDO('sqlite:' . $dbPath);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$db->exec("
CREATE TABLE shopping_lists (
    id TEXT PRIMARY KEY,
    title TEXT,
    type TEXT CHECK(type IN ('shopping', 'todo', 'checklist')),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    list_id TEXT,
    name TEXT,
    done BOOLEAN DEFAULT 0,
    step_number INTEGER,
    comment TEXT,
    FOREIGN KEY(list_id) REFERENCES shopping_lists(id)
);
");

echo "Database initialized at {$dbPath}\n";
