<?php
namespace App\Controller;

use PDO;

class ListController {
    private PDO $db;

    public function __construct() {
        $this->db = new PDO('sqlite:' . DB_PATH);
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    public function handleRequest(): void {
        $action = $_GET['action'] ?? 'home';
        switch ($action) {
            case 'create': $this->handleCreate(); break;
            case 'view': $this->handleView(); break;
            case 'add_item': $this->handleAddItem(); break;
            case 'delete_item': $this->handleDeleteItem(); break;
            case 'toggle_done': $this->handleToggleDone(); break;
            default: $this->renderHome(); break;
        }
    }

    private function renderHome(): void {
        echo '<!doctype html><html lang="sv"><head>
              <meta charset="utf-8">
              <title>Shoppinglistan</title>
              <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
              </head><body class="p-4">
              <div class="container">
              <h1>Skapa en ny lista</h1>
              <form method="POST" action="?action=create" class="row gy-2 gx-3 align-items-center">
                <div class="col-auto">
                  <input class="form-control" type="text" name="title" placeholder="Titel" required>
                </div>
                <div class="col-auto">
                  <select class="form-select" name="type">
                    <option value="shopping">Inköpslista</option>
                    <option value="todo">ToDo-lista</option>
                    <option value="checklist">Processlista</option>
                  </select>
                </div>
                <div class="col-auto">
                  <button class="btn btn-primary" type="submit">Skapa lista</button>
                </div>
              </form>
              </div></body></html>';
    }

    private function handleCreate(): void {
        $title = $_POST['title'] ?? '';
        $type = $_POST['type'] ?? 'shopping';
        $id = bin2hex(random_bytes(6));
        $stmt = $this->db->prepare("INSERT INTO shopping_lists (id, title, type) VALUES (?, ?, ?)");
        $stmt->execute([$id, $title, $type]);
        header("Location: ?action=view&id=$id");
        exit;
    }

    private function handleView(): void {
        $id = $_GET['id'] ?? '';
        $stmt = $this->db->prepare("SELECT * FROM shopping_lists WHERE id = ?");
        $stmt->execute([$id]);
        $list = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$list) {
            echo "<p>Listan hittades inte.</p>";
            return;
        }

        $items = $this->db->prepare("SELECT * FROM items WHERE list_id = ?");
        $items->execute([$id]);
        $rows = $items->fetchAll(PDO::FETCH_ASSOC);

        echo '<!doctype html><html lang="sv"><head>
              <meta charset="utf-8">
              <title>' . htmlspecialchars($list['title']) . '</title>
              <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
              </head><body class="p-4"><div class="container">';
        echo "<h2>" . htmlspecialchars($list['title']) . "</h2>";
        echo '<div class="mb-3"><button class="btn btn-outline-secondary" onclick="navigator.clipboard.writeText(window.location.href)">🔗 Kopiera länk</button></div>';
        echo '<ul class="list-group mb-3">';

        foreach ($rows as $item) {
            $checked = $item['done'] ? 'checked' : '';
            echo '<li class="list-group-item d-flex justify-content-between align-items-center">';
            echo '<form method="POST" action="?action=toggle_done&id=' . $id . '&item_id=' . $item['id'] . '" class="d-flex align-items-center w-100">';
            echo '<div class="form-check flex-grow-1">';
            echo '<input class="form-check-input me-2" type="checkbox" name="done" onchange="this.form.submit()" ' . $checked . '>';
            echo '<label class="form-check-label">' . htmlspecialchars($item['name']) . '</label>';
            echo '</div>';
            echo '<button class="btn btn-outline-danger btn-sm ms-2" formaction="?action=delete_item&id=' . $id . '&item_id=' . $item['id'] . '" formmethod="POST">🗑</button>';
            echo '</form></li>';
        }
        echo '</ul>';

        echo '<form method="POST" action="?action=add_item&id=' . $id . '" class="d-flex">
                <input class="form-control me-2" type="text" name="item" placeholder="Lägg till vara..." required>
                <button class="btn btn-success" type="submit">Lägg till</button>
              </form>';
        echo '</div></body></html>';
    }

    private function handleAddItem(): void {
        $id = $_GET['id'] ?? '';
        $item = $_POST['item'] ?? '';
        if ($item !== '') {
            $stmt = $this->db->prepare("INSERT INTO items (list_id, name) VALUES (?, ?)");
            $stmt->execute([$id, $item]);
        }
        header("Location: ?action=view&id=$id");
        exit;
    }

    private function handleDeleteItem(): void {
        $id = $_GET['id'] ?? '';
        $item_id = $_GET['item_id'] ?? '';
        $stmt = $this->db->prepare("DELETE FROM items WHERE id = ? AND list_id = ?");
        $stmt->execute([$item_id, $id]);
        header("Location: ?action=view&id=$id");
        exit;
    }

    private function handleToggleDone(): void {
        $id = $_GET['id'] ?? '';
        $item_id = $_GET['item_id'] ?? '';
        $stmt = $this->db->prepare("SELECT done FROM items WHERE id = ? AND list_id = ?");
        $stmt->execute([$item_id, $id]);
        $item = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($item) {
            $newStatus = $item['done'] ? 0 : 1;
            $update = $this->db->prepare("UPDATE items SET done = ? WHERE id = ? AND list_id = ?");
            $update->execute([$newStatus, $item_id, $id]);
        }
        header("Location: ?action=view&id=$id");
        exit;
    }
}
