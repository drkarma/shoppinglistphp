<?php

namespace App\Controller;

class ListController
{
    public function handle()
    {
        echo "<h1>Välkommen till din listapp!</h1>";
        echo "<p>Det här är ett första test av ListController::handle().</p>";
    }
}
