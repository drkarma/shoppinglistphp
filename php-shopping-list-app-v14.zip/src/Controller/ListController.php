<?php
// Placeholder - ska fyllas med funktionalitet
