<?php
require_once __DIR__ . '/../src/bootstrap.php';

$action = $_GET['action'] ?? '';
$id = $_GET['id'] ?? null;
$templateName = $_POST['template_name'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'create_template') {
    if (strlen($templateName) >= 5) {
        $stmt = $db->prepare("INSERT INTO templates (name) VALUES (?)");
        $stmt->execute([$templateName]);
        $templateId = $db->lastInsertId();

        if (!empty($_POST['steps'])) {
            foreach ($_POST['steps'] as $step) {
                if (!empty($step['title'])) {
                    $stmt = $db->prepare("INSERT INTO template_items (template_id, title, info, duration) VALUES (?, ?, ?, ?)");
                    $stmt->execute([$templateId, $step['title'], $step['info'], $step['duration']]);
                }
            }
        }
        header("Location: index.php?action=templates");
        exit;
    }
}

if ($action === 'templates') {
    $templates = $db->query("SELECT * FROM templates")->fetchAll(PDO::FETCH_ASSOC);
    ?>
    <h1>Skapa ny mall</h1>
    <form method="POST" action="?action=create_template">
        Namn på mall: <input type="text" name="template_name" required minlength="5"><br><br>
        <div id="steps">
            <div>
                <input type="text" name="steps[0][title]" placeholder="Titel" required>
                <input type="text" name="steps[0][info]" placeholder="Info">
                <input type="text" name="steps[0][duration]" placeholder="Tid/mängd">
            </div>
        </div>
        <button type="button" onclick="addStep()">Lägg till steg</button><br><br>
        <button type="submit">Spara mall</button>
    </form>

    <script>
    let stepIndex = 1;
    function addStep() {
        const div = document.createElement('div');
        div.innerHTML = `<input type="text" name="steps[${stepIndex}][title]" placeholder="Titel" required>
                         <input type="text" name="steps[${stepIndex}][info]" placeholder="Info">
                         <input type="text" name="steps[${stepIndex}][duration]" placeholder="Tid/mängd">`;
        document.getElementById('steps').appendChild(div);
        stepIndex++;
    }
    </script>

    <h2>Befintliga mallar</h2>
    <ul>
    <?php foreach ($templates as $template): ?>
        <li><?= htmlspecialchars($template['name']) ?></li>
    <?php endforeach; ?>
    </ul>
    <?php
    exit;
}
?>

<a href="?action=templates">Hantera mallar</a>
<form method="POST" action="?action=create">
    Titel: <input type="text" name="title" required><br>
    Typ: 
    <select name="type">
        <option value="shopping">Inköpslista</option>
        <option value="todo">ToDo-lista</option>
        <option value="checklist">Processchecklista</option>
    </select><br>
    <button type="submit">Skapa lista</button>
</form>
