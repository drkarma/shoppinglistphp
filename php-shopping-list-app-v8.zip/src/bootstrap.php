<?php
declare(strict_types=1);

$dbPath = __DIR__ . '/../data/shoppinglist.sqlite';
$db = new PDO('sqlite:' . $dbPath);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
