<?php
namespace App\Controller;

class ListController {
    public function handleRequest(): void {
        echo "Hello from ListController!";
    }
}
