<?php
namespace App\Controller;

use PDO;

class ListController {
    private PDO $db;

    public function __construct() {
        $this->db = new PDO('sqlite:' . DB_PATH);
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    public function handleRequest(): void {
        $action = $_GET['action'] ?? 'home';
        switch ($action) {
            case 'create': $this->handleCreate(); break;
            case 'view': $this->handleView(); break;
            case 'from_template': $this->renderTemplateForm(); break;
            case 'create_from_template': $this->createFromTemplate(); break;
            default: $this->renderHome(); break;
        }
    }

    private function renderHome(): void {
        echo '<!doctype html><html lang="sv"><head>
        <meta charset="utf-8">
        <title>Shoppinglistan</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
        </head><body class="p-4"><div class="container">
        <h1>Skapa en ny lista</h1>
        <form method="POST" action="?action=create" class="row gy-2 gx-3 align-items-center">
          <div class="col-auto">
            <input class="form-control" type="text" name="title" placeholder="Titel" required>
          </div>
          <div class="col-auto">
            <select class="form-select" name="type">
              <option value="shopping">Inköpslista</option>
              <option value="todo">ToDo-lista</option>
              <option value="checklist">Processmall</option>
            </select>
          </div>
          <div class="col-auto">
            <button class="btn btn-primary" type="submit">Skapa lista</button>
          </div>
        </form>
        <div class="mt-3">
          <form method="GET" action="">
            <input type="hidden" name="action" value="from_template">
            <button class="btn btn-outline-secondary" type="submit">Skapa processchecklista från mall</button>
          </form>
        </div>
        </div></body></html>';
    }

    private function handleCreate(): void {
        $title = $_POST['title'] ?? '';
        $type = $_POST['type'] ?? 'shopping';
        $id = bin2hex(random_bytes(6));
        $stmt = $this->db->prepare("INSERT INTO shopping_lists (id, title, type) VALUES (?, ?, ?)");
        $stmt->execute([$id, $title, $type]);
        header("Location: ?action=view&id=$id");
        exit;
    }

    private function handleView(): void {
        echo "<h1>Visa lista (placeholder)</h1>";
    }

    private function renderTemplateForm(): void {
        echo '<!doctype html><html lang="sv"><head>
        <meta charset="utf-8">
        <title>Använd processmall</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
        </head><body class="p-4"><div class="container">
        <h1>Skapa processchecklista från mall</h1>
        <form method="GET" action="?action=create_from_template" class="row gy-2 gx-3 align-items-center">
          <div class="col-auto">
            <label for="template" class="form-label">Mallnamn (minst 5 tecken):</label>
            <input class="form-control" type="text" name="template" id="template" required pattern=".{5,}">
          </div>
          <div class="col-auto">
            <button class="btn btn-primary" type="submit">Skapa från mall</button>
          </div>
        </form>
        </div></body></html>';
    }

    private function createFromTemplate(): void {
        $templateId = $_GET['template'] ?? '';
        if (strlen($templateId) < 5) {
            echo "<p>Ogiltigt mallnamn.</p>";
            return;
        }

        $templateStmt = $this->db->prepare("SELECT * FROM templates WHERE id = ?");
        $templateStmt->execute([$templateId]);
        $template = $templateStmt->fetch(PDO::FETCH_ASSOC);

        if (!$template) {
            echo "<p>Hittade ingen mall med ID: " . htmlspecialchars($templateId) . "</p>";
            return;
        }

        $newListId = bin2hex(random_bytes(6));
        $title = "Från mall: " . $template['name'];
        $this->db->prepare("INSERT INTO shopping_lists (id, title, type) VALUES (?, ?, 'checklist')")
            ->execute([$newListId, $title]);

        $items = $this->db->prepare("SELECT * FROM template_items WHERE template_id = ? ORDER BY step_order ASC");
        $items->execute([$templateId]);

        foreach ($items->fetchAll(PDO::FETCH_ASSOC) as $i => $item) {
            $name = $item['title'] . " — " . $item['info'] . " (" . $item['time_amount'] . ")";
            $this->db->prepare("INSERT INTO items (list_id, name, step_number) VALUES (?, ?, ?)")
                ->execute([$newListId, $name, $i + 1]);
        }

        header("Location: ?action=view&id=$newListId");
        exit;
    }
}
