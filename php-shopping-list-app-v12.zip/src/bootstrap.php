<?php
// Laddar autoload och konfiguration
