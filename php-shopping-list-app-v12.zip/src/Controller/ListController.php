<?php
// Hanterar listor
