<?php
// Initierar SQLite-databasen
