<?php
// Tar bort befintlig databas
