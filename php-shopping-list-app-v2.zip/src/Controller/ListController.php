<?php
namespace App\Controller;

use PDO;

class ListController {
    private PDO $db;

    public function __construct() {
        $this->db = new PDO('sqlite:' . DB_PATH);
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    public function handleRequest(): void {
        $action = $_GET['action'] ?? 'home';

        switch ($action) {
            case 'create':
                $this->handleCreate();
                break;
            case 'view':
                $this->handleView();
                break;
            case 'add_item':
                $this->handleAddItem();
                break;
            default:
                $this->renderHome();
        }
    }

    private function renderHome(): void {
        echo '<h1>Skapa en ny lista</h1>
              <form method="POST" action="?action=create">
                Titel: <input type="text" name="title" required><br>
                Typ: 
                <select name="type">
                  <option value="shopping">Inköpslista</option>
                  <option value="todo">ToDo-lista</option>
                  <option value="checklist">Processlista</option>
                </select><br>
                <button type="submit">Skapa lista</button>
              </form>';
    }

    private function handleCreate(): void {
        $title = $_POST['title'] ?? '';
        $type = $_POST['type'] ?? 'shopping';
        $id = bin2hex(random_bytes(6));

        $stmt = $this->db->prepare("INSERT INTO shopping_lists (id, title, type) VALUES (?, ?, ?)");
        $stmt->execute([$id, $title, $type]);

        header("Location: ?action=view&id=$id");
        exit;
    }

    private function handleView(): void {
        $id = $_GET['id'] ?? '';
        $stmt = $this->db->prepare("SELECT * FROM shopping_lists WHERE id = ?");
        $stmt->execute([$id]);
        $list = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$list) {
            echo "<p>Listan hittades inte.</p>";
            return;
        }

        echo "<h1>{$list['title']} ({$list['type']})</h1>";
        echo '<form method="POST" action="?action=add_item&id=' . $id . '">
                Lägg till post: <input type="text" name="item" required>
                <button type="submit">Lägg till</button>
              </form>';

        $stmt = $this->db->prepare("SELECT * FROM items WHERE list_id = ?");
        $stmt->execute([$id]);
        $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo "<ul>";
        foreach ($items as $item) {
            echo "<li>" . htmlspecialchars($item['name']) . "</li>";
        }
        echo "</ul>";
    }

    private function handleAddItem(): void {
        $id = $_GET['id'] ?? '';
        $item = $_POST['item'] ?? '';

        if ($item !== '') {
            $stmt = $this->db->prepare("INSERT INTO items (list_id, name) VALUES (?, ?)");
            $stmt->execute([$id, $item]);
        }

        header("Location: ?action=view&id=$id");
        exit;
    }
}
