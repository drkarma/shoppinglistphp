<?php
// HTML + Bootstrap GUI från v6 + utökad funktionalitet
