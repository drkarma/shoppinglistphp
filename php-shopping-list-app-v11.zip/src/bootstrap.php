<?php
// Startar session, laddar klasser
