#!/bin/bash
# Installerar senaste zip och initierar databasen
