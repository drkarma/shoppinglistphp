<?php
// Ta bort databasen om den finns
