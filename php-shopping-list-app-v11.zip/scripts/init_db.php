<?php
// Skapa SQLite-db med listor, mallar och checklistor
