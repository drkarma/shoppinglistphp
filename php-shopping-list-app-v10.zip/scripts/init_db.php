<?php
echo 'Database initialized';
