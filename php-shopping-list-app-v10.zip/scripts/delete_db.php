<?php
echo 'Database deleted';
